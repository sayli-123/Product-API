﻿using productAPI.Models;
using System.Threading.Tasks;

namespace productAPI.Repository
{
    public interface IProduct
    {
        //Task<IEnumerable<T>> GetAllAsync(int? categoryId = null);
        //Task<T> GetByIdAsync(int id);
        //Task<T> AddAsync(T entity);
        //Task UpdateAsync(T entity);
        //Task DeleteAsync(int id);


        Task<IEnumerable<Product>> GetAllAsync(int? categoryId = null);
        Task<Product> GetByIdAsync(int id);
        Task<Product> AddAsync(Product product);
        Task UpdateAsync(Product product);
        Task DeleteAsync(int id);
    }
}
