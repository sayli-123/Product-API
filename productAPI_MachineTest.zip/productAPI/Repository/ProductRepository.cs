﻿using Microsoft.EntityFrameworkCore;
using productAPI.Models;
using Microsoft.EntityFrameworkCore;
using productAPI.Data;

namespace productAPI.Repository
{
    public class ProductRepository : IProduct
    {
        //protected readonly DbSet<T> _dbSet;
        private readonly ProductDbContext _productDbContext;
        public ProductRepository(ProductDbContext productDbContext)
        {
           // _dbSet = _productDbContext.Set<T>();
            _productDbContext = productDbContext;
        }
        public async Task<IEnumerable<Product>> GetAllAsync(int? categoryId = null)
        {
            var query = _productDbContext.Products.Include(p => p.Category).AsQueryable();
            if (categoryId.HasValue)
                query = query.Where(p => p.CategoryId == categoryId);
            return await query.ToListAsync();
        }

        public async Task<Product> GetByIdAsync(int id) =>
            await _productDbContext.Products.Include(p => p.Category).FirstOrDefaultAsync(p => p.Id == id);

        public async Task<Product> AddAsync(Product product)
        {
            _productDbContext.Products.Add(product);
            await _productDbContext.SaveChangesAsync();
            return product;
        }

        public async Task UpdateAsync(Product product)
        {
            _productDbContext.Products.Update(product);
            await _productDbContext.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var product = await _productDbContext.Products.FindAsync(id);
            if (product != null)
            {
                _productDbContext.Products.Remove(product);
                await _productDbContext.SaveChangesAsync();
            }
        }
        //public async Task<T> AddAsync(T entity)
        //{
        //    await _dbSet.AddAsync(entity);
        //    await _productDbContext.SaveChangesAsync();
        //    return entity;
        //}

        //public Task DeleteAsync(int id)
        //{
        //    throw new NotImplementedException();
        //}

        //public async Task DeleteAsync(T entity)
        //{
        //     _dbSet.Remove(entity);
        //    await _productDbContext.SaveChangesAsync();

        //}

        //public Task<IEnumerable<Product>> GetAllAsync(int? categoryId = null)
        //{
        //    throw new NotImplementedException();
        //}

        //public async Task<IEnumerable<T>> GetAllAsync()
        //{
        //   return await _dbSet.ToListAsync();
        //}

        //public async Task<T> GetByIdAsync(int id)
        //{
        //    return await _dbSet.FindAsync(id);
        //}

        //public Task UpdateAsync(Product product)
        //{
        //    throw new NotImplementedException();
        //}

        //public async Task UpdateAsync(T entity)
        //{
        //   _dbSet.AddAsync(entity);
        //    _productDbContext.Entry(entity).State = EntityState.Modified;
        //    await _productDbContext.SaveChangesAsync();

        //}

        //Task<IEnumerable<T>> IProduct<T>.GetAllAsync(int? categoryId)
        //{
        //    throw new NotImplementedException();
        //}

        //Task<T> IProduct<T>.GetByIdAsync(int id)
        //{
        //    throw new NotImplementedException();
        //}
    }


}
