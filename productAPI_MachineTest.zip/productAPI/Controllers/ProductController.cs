﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using productAPI.Models;
using productAPI.Repository;

namespace productAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProduct _productRepository;
        public ProductController(IProduct productRepository)
        {
            _productRepository = productRepository;


        }
       

        
        [HttpGet]
        public async Task<IActionResult> GetAll([FromQuery] int? categoryId) =>
        Ok(await _productRepository.GetAllAsync(categoryId));

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var product = await _productRepository.GetByIdAsync(id);
            return product == null ? NotFound() : Ok(product);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Product product)
        {
            var created = await _productRepository.AddAsync(product);
            return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, Product product)
        {
            if (id != product.Id) return BadRequest();
            await _productRepository.UpdateAsync(product);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _productRepository.DeleteAsync(id);
            return NoContent();
        }







        //    [HttpGet]
        //    public async Task<IActionResult> GetAll()
        //    {
        //        var products = await _productRepository.GetAllAsync();
        //        return Ok(products);
        //    }
        //    [HttpGet("{id}")]
        //    public async Task<IActionResult> GetById(int id)
        //    {
        //        var product = await _productRepository.GetByIdAsync(id);
        //        if (product == null) 
        //        {
        //            return NotFound();
        //        }
        //        return Ok(product);
        //    }

        //    [HttpPost]
        //    public async Task<IActionResult> Post([FromBody] ProductRequest product)
        //    {
        //        var productEntity = new Product()
        //        {
        //            ProductName = product.Name,
        //            Price = product.Price,
        //        };
        //        var CreateProductReponse = await _productRepository.AddAsync(productEntity);
        //        return CreatedAtAction(nameof(GetById), new { id = CreateProductReponse.Id }, CreateProductReponse.Name ,CreateProductReponse.Description,CreateProductReponse.Price, CreateProductReponse.Quantity)
        //}
    }
}
